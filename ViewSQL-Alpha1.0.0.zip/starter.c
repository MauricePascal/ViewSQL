#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
    system("npm install");
    system("npm start");
    return 0;
}